<?php

// Text
$_['text_title']       = 'N-Genius Payment Gateway';
$_['text_credit_card'] = 'Credit Card Details';
$_['text_testing']     = 'This payment gatngenius is currently being tested.
 Your credit card will not be charged.<br />If this is a real order,
  please use an alternate method of payment at this time.';

$_['text_basket']   = 'Basket';
$_['text_checkout'] = 'Checkout';
$_['text_success']  = 'Success';
$_['text_shipping'] = 'Shipping';
$_['button_pay']    = 'Pay now';
